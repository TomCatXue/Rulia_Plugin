# 禁漫天堂

禁漫天堂（18comic）漫画源插件，移植自 keiyoushi 的 JinmanTiantang 扩展。

## 说明

- 列表 / 搜索 / 详情 / 章节 / 图片接口均已实网验证。
- 内置纯 JS 的 MD5 与 AES-256-ECB 解密，与官方扩展一致。
- 封面使用 API 服务器域名（如 `www.cdnhjk.net`），不经过会校验 UA 的 `cdn-msp` CDN。

## 依赖

- 章节图为 WebP，Windows 需安装「WebP 图像扩展」，否则图片无法解码（`0x88982F50`）。

## 已知限制

- 章节图片（album id ≥ 220980）在 CDN 上是「行打乱」的，`getImageUrl` 里用 canvas 尽力还原；若环境不支持则退回原图（此时图片是打乱的）。
- 登录 / 收藏 / 签到未实现。
